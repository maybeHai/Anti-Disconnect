Hello! Thank you so much for downloading. Heres how to set it up.

# Open the Check folder

1. First, run the install.bat file.
2. Second, run the dependencies_check.bat file.
3. Run the run.bat file.