import pyautogui
import time
import threading
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import psutil

class KeepActiveApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Roblox Anti-Disconnect")
        self.root.geometry("400x250")
        self.root.configure(bg="#2e3f4f")
        self.running = False

        style = ttk.Style()
        style.configure("TLabel", background="#2e3f4f", foreground="#ffffff", font=("Helvetica", 12))
        style.configure("TButton", font=("Helvetica", 12), padding=10)
        style.map("TButton", background=[('active', '#3b4b5b')], foreground=[('active', '#ffffff')])
        style.configure("TEntry", font=("Helvetica", 12), padding=5)

        # Create and place the labels and entry widgets
        ttk.Label(root, text="Interval (seconds):").grid(row=0, column=0, padx=10, pady=10, sticky="w")
        self.interval_entry = ttk.Entry(root)
        self.interval_entry.grid(row=0, column=1, padx=10, pady=10)

        ttk.Label(root, text="Move Distance (pixels):").grid(row=1, column=0, padx=10, pady=10, sticky="w")
        self.distance_entry = ttk.Entry(root)
        self.distance_entry.grid(row=1, column=1, padx=10, pady=10)

        # Create and place the start/stop button
        self.start_button = ttk.Button(root, text="Start", command=self.start)
        self.start_button.grid(row=2, column=0, padx=10, pady=20)

        self.stop_button = ttk.Button(root, text="Stop", command=self.stop, state=tk.DISABLED)
        self.stop_button.grid(row=2, column=1, padx=10, pady=20)

        self.status_label = ttk.Label(root, text="Status: Stopped")
        self.status_label.grid(row=3, columnspan=2, pady=10)

    def is_roblox_running(self):
        # Check if Roblox process is running
        for process in psutil.process_iter(['pid', 'name']):
            if "Roblox" in process.info['name']:
                return True
        return False

    def start(self):
        interval = self.interval_entry.get()
        distance = self.distance_entry.get()

        if not interval.isdigit() or not distance.isdigit():
            messagebox.showerror("Invalid input", "Please enter valid numbers for interval and move distance.")
            return
        elif not interval.isdigit():
            messagebox.showerror("Invalid input", "Please enter a valid number for interval.")
            return
        elif not distance.isdigit():
            messagebox.showerror("Invalid input", "Please enter a valid number for move distance.")
            return

        if not self.is_roblox_running():
            messagebox.showerror("Roblox not found", "Roblox is not running. Please start Roblox before using this tool.")
            return

        self.interval = int(interval)
        self.move_distance = int(distance)
        self.running = True
        self.status_label.config(text="Status: Running")

        self.start_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)

        # Run the keep_active function in a separate thread
        self.thread = threading.Thread(target=self.keep_active)
        self.thread.start()

    def stop(self):
        self.running = False
        self.status_label.config(text="Status: Stopped")
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)

    def keep_active(self):
        while self.running:
            # Get the current mouse position
            x, y = pyautogui.position()
            # Move the mouse slightly
            pyautogui.moveRel(self.move_distance, 0, duration=0.1)  # Move right
            pyautogui.moveRel(-self.move_distance, 0, duration=0.1) # Move back to original position
            print("Moved mouse to keep session active.")
            # Wait for the interval before the next movement
            time.sleep(self.interval)

if __name__ == "__main__":
    root = tk.Tk()
    app = KeepActiveApp(root)
    root.mainloop()
